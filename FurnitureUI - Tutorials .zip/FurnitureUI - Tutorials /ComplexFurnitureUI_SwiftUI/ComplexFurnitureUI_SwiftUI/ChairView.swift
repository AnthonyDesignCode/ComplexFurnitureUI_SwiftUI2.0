//
//  ChairView.swift
//  ComplexFurnitureUI_SwiftUI
//
//  Created by Anthony Codes on 20/09/2020.
//

import SwiftUI

struct ChairView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct ChairView_Previews: PreviewProvider {
    static var previews: some View {
        ChairView()
    }
}
