//
//  ComplexFurnitureUI_SwiftUIApp.swift
//  ComplexFurnitureUI_SwiftUI
//
//  Created by Anthony Codes on 20/09/2020.
//

import SwiftUI

@main
struct ComplexFurnitureUI_SwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
