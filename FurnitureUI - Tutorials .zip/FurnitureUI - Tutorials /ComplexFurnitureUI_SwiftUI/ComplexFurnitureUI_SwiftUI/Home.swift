//
//  Home.swift
//  ComplexFurnitureUI_SwiftUI
//
//  Created by Anthony Codes on 20/09/2020.
//

import SwiftUI

struct Home: View {
    var body: some View {
            ZStack {
                Rectangle()
                    .fill(Color("BackgroundLight")).ignoresSafeArea(.all)
            }
            .overlay(
                HStack {
                    Rectangle()
                        .fill(Color("BackgroundDark"))
                        .frame(width: 80)
                    Rectangle()
                        .fill(Color("BackgroundLight"))
            })
        .edgesIgnoringSafeArea(.all)
        .overlay(
            VStack(spacing: 10) {
                HStack(spacing: 20) {
                    Text("DashBoard")
                        .font(.system(size: 32, weight: .bold, design: .rounded))
                        .foregroundColor(Color("ButtonDark"))
                        .padding(.trailing, 70)
                    Image(systemName: "person.circle")
                        .font(.system(size: 25, weight: .regular, design: .rounded))
                        .foregroundColor(Color("ButtonDark"))
                    Image(systemName: "magnifyingglass.circle")
                        .font(.system(size: 25, weight: .regular, design: .rounded))
                        .foregroundColor(Color("ButtonDark"))
                    
                }.padding(.all)
                VStack(spacing: 10) {
                    Text("Welcome,")
                        .font(.system(size: 25, weight: .bold, design: .rounded))
                        .foregroundColor(Color("ButtonDark"))
                        .padding(.trailing, 210)
                    Text("AnthonyDesignCode")
                        .font(.system(size: 25, weight: .bold, design: .rounded))
                        .foregroundColor(Color("ButtonDark"))
                        .padding(.trailing, 80)
                }
                Spacer()
                VerticalMenu()
                    .padding(.vertical, 125)
                    .frame(width: 400)
                    .rotationEffect(.init(degrees: -90))
                    .padding(.leading, -320)
                    .zIndex(1)
                Spacer()
                Spacer()
            }).overlay(
                VStack(spacing: 10){
                    CardView()
        }).overlay(
            VStack {
                TabBar()
                    .padding(.top, 795)
                    .padding(.bottom, 5)
        })
    }
}

struct Home_Previews: PreviewProvider {
    static var previews: some View {
        Home()
    }
}
struct VerticalMenu: View {
    @State var index = 0 // Selection
    
    var body: some View {
        HStack(spacing: 20) {
            Button {
                index = 4 //This is the first item selected in the menu.
            } label: {
                VStack(spacing: 10) {
                    Text("Bedroom")
                        .fontWeight(index == 4 ? .heavy : .none)
                        .foregroundColor(index == 4 ? Color("ButtonDark") : .gray)
                    //Adding a Shape under the Text
                    Rectangle()
                        .fill(index == 4 ? Color("ButtonLight") : Color.gray.opacity(index == 4 ? 1 : 0))
                        .frame(width: 35, height: 5)
                        .cornerRadius(3.0)
                }
            }.padding(.trailing, 0)
            Button {
                index = 3 //This is the second item selected in the menu.
            } label: {
                VStack(spacing: 10) {
                    Text("Outdoor")
                        .fontWeight(index == 3 ? .heavy : .none)
                        .foregroundColor(index == 3 ? Color("ButtonDark") : .gray)
                    //Adding a Shape under the Text
                    Rectangle()
                        .fill(index == 3 ? Color("ButtonLight") : Color.gray.opacity(index == 3 ? 1 : 0))
                        .frame(width: 35, height: 5)
                        .cornerRadius(3.0)
                }
            }
            Button {
                index = 2
            } label: {
                VStack(spacing: 10) {
                    Text("Office")
                        .fontWeight(index == 2 ? .heavy : .none)
                        .foregroundColor(index == 2 ? Color("ButtonDark") : .gray)
                    //Adding a Shape under the Text
                    Rectangle()
                        .fill(index == 2 ? Color("ButtonLight") : Color.gray.opacity(index == 2 ? 1 : 0))
                        .frame(width: 35, height: 5)
                        .cornerRadius(3.0)
                }
            }
            Button {
                index = 1
            } label: {
                VStack(spacing: 10) {
                    Text("Livingroom")
                        .fontWeight(index == 1 ? .heavy : .none)
                        .foregroundColor(index == 1 ? Color("ButtonDark") : .gray)
                    //Adding a Shape under the Text
                    Rectangle()
                        .fill(index == 1 ? Color("ButtonLight") : Color.gray.opacity(index == 1 ? 1 : 0))
                        .frame(width: 35, height: 5)
                        .cornerRadius(3.0)
                }
            }
            Button {
                index = 0
            } label: {
                VStack(spacing: 10) {
                    Text("All")
                        .fontWeight(index == 0 ? .heavy : .none)
                        .foregroundColor(index == 0 ? Color("ButtonDark") : .gray)
                    //Adding a Shape under the Text
                    Rectangle()
                        .fill(index == 0 ? Color("ButtonLight") : Color.gray.opacity(index == 0 ? 1 : 0))
                        .frame(width: 35, height: 5)
                        .cornerRadius(3.0)
                }
            }.padding(.trailing, 0)
        }
    }
}

struct CardView: View {
    var body: some View {
        VStack(spacing: 10) {
            HStack(alignment: .center, spacing: 20) {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack {
                        ZStack {
                            Section {
                                Rectangle()
                                    .fill(Color("ButtonLight"))
                                    .frame(width: 200, height: 390)
                                    .cornerRadius(10)
                                Rectangle()
                                    .fill(LinearGradient(gradient: Gradient(colors: [Color("BackgroundDark"), Color("BackgroundLight")]), startPoint: .leading, endPoint: .trailing))
                                    .frame(width: 200, height: 380)
                                    .cornerRadius(10)
                                    .padding(.top, 80)
                                
                            }.overlay(
                                VStack {
                                    Image("chairOne")
                                        .padding(.bottom, 225)
                                   
                                }
                            )
                            HStack(spacing: 5) {
                                HStack(alignment: .bottom) {
                                    Text("FANBYE")
                                        .font(.system(size: 25, weight: .heavy, design: .rounded))
                                        .foregroundColor(Color("ButtonDark"))
                                        .padding(.trailing, 30)
                                    Text("£")
                                        .font(.subheadline)
                                        .foregroundColor(Color("ButtonDark"))
                                    Text("60")
                                        .font(.system(size: 25, weight: .heavy, design: .rounded))
                                        .foregroundColor(Color("ButtonDark"))
                                }.padding(.top, 20)
                            }
                            VStack {
                                Text("Chair, grey")
                                    .font(.system(size: 12, weight: .regular, design: .rounded))
                                    .foregroundColor(Color("ButtonDark"))
                                    .padding(.trailing, 119)
                                
                                HStack(spacing: 15) {
                                    Image(systemName: "star.fill")
                                        .font(.title)
                                        .frame(width: 20, height: 20)
                                        .foregroundColor(Color("ButtonDark"))
                                        .padding(.top, 20)
                                        //.padding(.trailing, 10)
                                    Image(systemName: "star.fill")
                                        .font(.title)
                                        .frame(width: 20, height: 20)
                                        .foregroundColor(Color("ButtonDark"))
                                        .padding(.top, 20)
                                        //.padding(.trailing, 10)
                                    Image(systemName: "star.fill")
                                        .font(.title)
                                        .frame(width: 20, height: 20)
                                        .foregroundColor(Color("ButtonDark"))
                                        .padding(.top, 20)
                                        //.padding(.trailing, 10)
                                    Image(systemName: "star.fill")
                                        .font(.title)
                                        .frame(width: 20, height: 20)
                                        .foregroundColor(Color("BackgroundDark"))
                                        .padding(.top, 20)
                                        //.padding(.trailing, 10)
                                    Image(systemName: "star.fill")
                                        .font(.title)
                                        .frame(width: 20, height: 20)
                                        .foregroundColor(Color("BackgroundDark"))
                                        .padding(.top, 20)
                                        //.padding(.trailing, 10)
                                }
                                HStack(spacing: 10) {
                                    Circle()
                                        .foregroundColor(.gray)
                                        .frame(width: 50, height: 50)
                                    Circle()
                                        .foregroundColor(.white)
                                        .frame(width: 50, height: 50)
                                }
                                .padding(.top, 25)
                                .padding(.trailing, 60)
                            }
                            .padding(.top, 200)
                            .padding(.trailing, 9)
                        }
                        Spacer()
                        Spacer()
                        ZStack {
                            Section {
                                Rectangle()
                                    .fill(Color("ButtonLight"))
                                    .frame(width: 200, height: 390)
                                    .cornerRadius(10)
                                Rectangle()
                                    .fill(LinearGradient(gradient: Gradient(colors: [Color("BackgroundDark"), Color("BackgroundLight")]), startPoint: .leading, endPoint: .trailing))
                                    .frame(width: 200, height: 380)
                                    .cornerRadius(10)
                                    .padding(.top, 80)
                            }.overlay(
                                VStack {
                                   Image("chairTwo")
                                    .padding(.bottom, 225)
                                }
                            )
                            HStack(spacing: 0) {
                                HStack(alignment: .bottom) {
                                    Text("SKRUVSTA")
                                        .font(.system(size: 25, weight: .heavy, design: .rounded))
                                        .foregroundColor(Color("ButtonDark"))
                                        .padding(.leading, 3)
                                    Text("£")
                                        .font(.subheadline)
                                        .foregroundColor(Color("ButtonDark"))
                                    Text("99")
                                        .font(.system(size: 25, weight: .heavy, design: .rounded))
                                        .foregroundColor(Color("ButtonDark"))
                                }
                                .padding(.top, 20)
                                
                            }
                            VStack {
                                Text("Swivel Chair, Idhult black")
                                    .font(.system(size: 12, weight: .regular, design: .rounded))
                                    .foregroundColor(Color("ButtonDark"))
                                    .padding(.trailing, 40)
                                
                                HStack(spacing: 15) {
                                    Image(systemName: "star.fill")
                                        .font(.title)
                                        .frame(width: 20, height: 20)
                                        .foregroundColor(Color("ButtonDark"))
                                        .padding(.top, 20)
                                        //.padding(.trailing, 10)
                                    Image(systemName: "star.fill")
                                        .font(.title)
                                        .frame(width: 20, height: 20)
                                        .foregroundColor(Color("ButtonDark"))
                                        .padding(.top, 20)
                                        //.padding(.trailing, 10)
                                    Image(systemName: "star.fill")
                                        .font(.title)
                                        .frame(width: 20, height: 20)
                                        .foregroundColor(Color("ButtonDark"))
                                        .padding(.top, 20)
                                        //.padding(.trailing, 10)
                                    Image(systemName: "star.leadinghalf.fill")
                                        .font(.title)
                                        .frame(width: 20, height: 20)
                                        .foregroundColor(Color("ButtonDark"))
                                        .padding(.top, 20)
                                        //.padding(.trailing, 10)
                                    Image(systemName: "star.leadinghalf.fill")
                                        .font(.title)
                                        .frame(width: 20, height: 20)
                                        .foregroundColor(Color("ButtonDark"))
                                        .padding(.top, 20)
                                        //.padding(.trailing, 10)
                                }
                                HStack(spacing: 10){
                                    Circle()
                                        .foregroundColor(.black)
                                        .frame(width: 50, height: 50)
                                    Circle()
                                        .foregroundColor(.gray)
                                        .frame(width: 50, height: 50)
                                    Circle()
                                        .foregroundColor(.white)
                                        .frame(width: 50, height: 50)
                                }
                                .padding(.top, 25)
                                .padding(.trailing, 0)
                            }
                            .padding(.top, 200)
                            .padding(.trailing, 9)
                        }
                    }
                }
                .padding(.top, 90)
                .padding(.leading, 100)
            }
        }
    }
}

struct TabBar: View {
    var body: some View {
        ZStack {
            Rectangle()
                .fill(Color.white)
                .frame(width: 425, height: 100)
                .overlay(
                    HStack(alignment: .center, spacing: 20) {
                        Image("Home")
                        Spacer()
                        Image(systemName: "bookmark")
                            .font(.largeTitle)
                            .foregroundColor(Color("BackgroundDark"))
                    }
                    .padding(.leading, 80)
                    .padding(.trailing, 95)
                    .overlay(
                        VStack {
                            Circle()
                                .fill(Color("ButtonLight"))
                                .frame(width: 70, height: 70)
                                .shadow(color: Color("ButtonLight").opacity(0.6), radius: 5, x: 0.0, y: 7)
                                .padding(.bottom, 70)
                                .overlay(
                                    Image(systemName: "plus")
                                        .font(.system(size: 45, weight: .regular , design: .rounded))
                                        .foregroundColor(Color("BackgroundDark"))
                                        .padding(.bottom, 70)
            )}))
        }
    }
}
