//
//  Home.swift
//  ComplexUI_Test
//
//  Created by Anthony Codes on 11/09/2020.
//

import SwiftUI

struct Home: View {
    
    //Create SearchBar
    @State var search = ""
    //Create Menu
    @State var selectedMenu = "All"
    @State var selected: Item = items[0]
    //Animations
    @Namespace var animation
    @State var show = false
    
    
    var body: some View {
        ZStack {
            VStack {
                HStack {
                    Text("Welcome")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(Color("TextColor"))
                    Spacer()
                    Button(action: {}) {
                        ZStack(alignment: Alignment(horizontal: .trailing, vertical: .top)) {
                            Image(systemName: "bell.fill") //This can be whatever icon you wish to use.
                                .font(.system(size: 25))
                                .foregroundColor(Color("TextColor"))
                            //As we are using a bell icon we can add a circle shape to show a notification.
                            Circle()
                                .fill(Color("Color"))
                                .frame(width: 12, height: 12)
                        }
                    }
                }.padding()
                HStack(spacing: 15) {
                    //Creating the SearchBar
                    Image(systemName: "magnifiyingglass")
                        .font(.title2)
                        .foregroundColor(Color("TextColor"))
                    //We are going to create a TextField
                    TextField("Search", text: $search)
                        .foregroundColor(Color("TextColor"))
                        .preferredColorScheme(.light)//This is the color of Text
                }
                .padding()
                .background(Color("search"))
                .cornerRadius(10)
                .padding()
                
                HStack(spacing: 5) {
                    ForEach(menus, id: \.self) {title in
                        MenuButton(title: title, selected: $selectedMenu)
                        if title != menus.last {
                            Spacer(minLength: 0)
                        }
                    }
                }.padding()
                
                //ScrollView
                ScrollView(.vertical, showsIndicators: false) {
                    VStack(spacing: 20) {
                        ForEach(items){item in
                            CardView(item: item, animation: animation)
                                .shadow(color: Color("Color").opacity(0.2), radius : 2, x: 0, y: 2)
                                .onTapGesture {
                                    withAnimation(.spring()){
                                        selected = item
                                        show.toggle()
                                    }
                                }
                        }
                    }.padding(.horizontal, 22)
                }
                .padding(.vertical)
                .background(
                    Color("detailBg")
                        .clipShape(CustomCorner(corners: [.topLeft, .topRight], size: 55))
                        .ignoresSafeArea(.all, edges: .bottom)
                        .padding(.top, 70)
                )
            }
            if show {
                DetailView(item: $selected, show: $show, animation: animation)
            }
        }.background(Color("bg").ignoresSafeArea(.all, edges: .all))
    }
}

struct Home_Previews: PreviewProvider {
    static var previews: some View {
        Home()
    }
}
// Model And Model Data...
struct Item : Identifiable {
    var id = UUID().uuidString
    var image : String
    var title : String
    var price : String
}
var items = [
    Item(image: "p1", title: "HEKTAR" ,price: "£45"),
    Item(image: "p2", title: "LAUTERS" ,price: "£50"),
    Item(image: "p3", title: "HOLMO" ,price: "£6"),
]

// MENU
var menus = ["All", "Livingroom", "Office"]

struct MenuButton: View {
    
    var title : String
    @Binding var selected : String
    
    var body: some View {
        Button(action: {selected = title}) {
            Text(title)
                .font(.system(size: 20))
                .fontWeight(selected == title ? .bold : .none)
                .foregroundColor(selected == title ? Color("TextColor") : Color("TextColor").opacity(0.7))
                .padding(.vertical, 10)
                .padding(.horizontal, 20)
                .background(Color("search").opacity(selected == title ? 1 : 0))
                .cornerRadius(10)
        }
    }
}

// CustomShape
struct CustomCorner: Shape {
    var corners : UIRectCorner
    var size : CGFloat
    
    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: corners, cornerRadii: CGSize(width: size, height: size))
        return Path(path.cgPath)
    }
}

// Cards
struct CardView : View {
    
    var item : Item
    var animation : Namespace.ID
    
    var body: some View {
        ZStack(alignment: Alignment(horizontal: .leading, vertical: .bottom)) {
            HStack(spacing: 10) {
                Text(item.title)
                    .font(.title3)
                    .fontWeight(.bold)
                    //.layoutPriority(2)
                    .foregroundColor(Color("TextColor"))
                Spacer(minLength: 0)
                Image(item.image)
                    .resizable()
                    .aspectRatio(contentMode: .fit )
                    .frame(height: 180) //Maxsize
                    .matchedGeometryEffect(id: item.image, in: animation)
            }
            .padding(.horizontal)
            .padding(.bottom)
            .background(Color.white.cornerRadius(25).padding(.top, 35))
            .padding(.trailing, 8)
            .background(Color("Color").cornerRadius(25).padding(.top, 35))
            
            Text(item.price)
                .fontWeight(.bold)
                .foregroundColor(.white)
                .padding(.vertical, 10)
                .padding(.horizontal, 35)
                .background(Color("Color1"))
                .clipShape(CustomCorner(corners: [.topRight, .bottomLeft], size: 15))
        }
    }
}

// DetailView
struct DetailView : View {
    
    @Binding var item : Item
    @Binding var show : Bool
    //Hero Animation
    var animation : Namespace.ID
    var colors : [Color] = [.gray, .white, .black]
    @State var selectedColor : Color = .gray
    
    var body: some View {
        VStack {
            VStack {
                HStack {
                    Button(action: {
                        withAnimation(.spring()){show.toggle()}
                    }) {
                        HStack(spacing: 10) {
                            Image(systemName: "arrow.left")
                                .font(.system(size: 24))
                                .foregroundColor(Color("TextColor"))
                            //Text("BACK")
                              //  .foregroundColor(.black)
                        }
                    }
                    Spacer()
                    Button(action: {}) {
                        ZStack(alignment: Alignment(horizontal: .leading, vertical: .top)) {
                            Image(systemName: "bag")
                                .font(.system(size: 25))
                                .foregroundColor(Color("TextColor"))
                            Circle()
                                .fill(Color("Color"))
                                .frame(width: 12, height: 12)
                                .offset(x: -5, y: -5)
                            
                        }
                    }
                }.padding()
                
                Image(item.image)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .padding(.horizontal, 45)
                    .background(Color.white.clipShape(Circle()).padding(.top, 50))
                    .matchedGeometryEffect(id: item.image, in: animation)
                    .padding(.top, 25)
                
                HStack(spacing: 25) {
                    ForEach(colors, id: \.self){color in
                        Button(action: {selectedColor = color}) {
                            ZStack {
                                Circle()
                                    .fill(color)
                                    .frame(width: 24, height: 24)
                                Circle()
                                    .stroke(Color.black, lineWidth: 1)
                                    .frame(width: 32, height: 32)
                                    .opacity(selectedColor == color ? 1 : 0)
                            }
                        }
                    }
                }
                .padding(.top, 25)
                
                VStack(alignment: .leading, spacing: 12) {
                    Text(item.title)
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(Color("TextColor"))
                        .padding(.top, 8)
                    Text(item.price)
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(Color("TextColor"))
                        .padding(.top, 8)
                    Text("Floor lamp")
                        .multilineTextAlignment(.leading)
                        .foregroundColor(Color("TextColor"))
                }
                .padding()
                .padding(.horizontal, 10)
            }
            .padding(.bottom, 10)
            .background(Color("detailBg").clipShape(CustomCorner(corners: [.bottomLeft, .bottomRight], size: 45)).ignoresSafeArea(.all, edges: .top))
            Button(action: {}) {
                Text("Add to Cart")
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                    .padding(.vertical)
                    .frame(width: UIScreen.main.bounds.width - 45)
                    .background(Color("Color"))
                    .clipShape(Capsule())
                    .padding(.vertical)
            }
        }
        .background(Color("bg"))
        .ignoresSafeArea(.all, edges: .bottom)
    }
}
