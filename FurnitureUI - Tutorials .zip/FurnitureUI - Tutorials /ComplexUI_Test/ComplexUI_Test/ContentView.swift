//
//  ContentView.swift
//  ComplexUI_Test
//
//  Created by Anthony Codes on 11/09/2020.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
       Home()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
