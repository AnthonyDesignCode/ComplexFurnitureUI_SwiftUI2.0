//
//  ComplexUI_TestApp.swift
//  ComplexUI_Test
//
//  Created by Anthony Codes on 11/09/2020.
//

import SwiftUI

@main
struct ComplexUI_TestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
